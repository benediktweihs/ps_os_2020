//
// Created by benedikt on 26.04.20.
//

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdint.h>
#include <string.h>
#include <semaphore.h>
#include <time.h>
#ifndef H_GUARD
#define H_GUARD

#define MAXDIR 256
#define BUFSIZE 10
#define SEMPROD "/synchCirkArrPr"
#define SEMCONS "/synchCirkArrCr"

// struct is stored in shared memory
typedef struct content{
	uint64_t n;
	uint64_t buffer[BUFSIZE];
} content;

// Print system error and exit
void error(char *msg){
    perror(msg);
    exit(EXIT_FAILURE);
}

#endif
