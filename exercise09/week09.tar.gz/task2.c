//
// Created by benedikt on 26.05.20.
//
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define block 1024

void* my_malloc(int T, int S, void* segment, bool* blocks){
	int max = 0;
	int highLow = 0;
	int highUp = 0;
	int highOverall = 0;
	int index = 0;
	int firstFree = 0;
	bool low = true;
	bool inGap = False;

    for(int i = 0; i < T; i++){
		if(blocks[i] && low){
			inGap = False;
			max++;
			continue;
		}
		if(blocks[i] && !low){
			inGap = False;
			max++;
			continue;
		}
		// Gap in memory alloc
		if(!blocks[i] && low && !inGap){
            if(low) highLow = max;
			else highUp = max;
			if(highLow+highUp>highOverall){
				highOverall = highLow + highUp;
				index = firstFree;
			}
			inGap = true;
            max = 0;
            low = false;
			firstFree = i;
		}
	}
	blocks[index] = True;
	return (void*) &index;
}

void my_free(void* ptr, int T, int S, void* segment, bool* blocks){
	blocks[(int) *ptr] = false;
    return free(ptr);
}
